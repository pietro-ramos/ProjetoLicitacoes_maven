-- CREATE TABLE categorias (
--     "id" serial not null,
--     "nome" varchar(30) not null,
--     CONSTRAINT "categorias_PK" PRIMARY KEY ("id")
-- );
DROP TABLE "endereco" CASCADE;
DROP TABLE "fornecedores" CASCADE; 

SELECT * FROM "endereco";
SELECT * FROM "fornecedores";

CREATE TABLE endereco (
    "id" serial not null,
    "UF" char(2) not null,
    "municipio" varchar(30) not null,
    "rua" varchar(50) not null,
    "numero" int not null,
    CONSTRAINT "endereco_PK" PRIMARY KEY ("id")
);

CREATE TABLE fornecedores (
    "id" serial not null,
    "nome" varchar(50) not null,
    "cnpj"char(18) UNIQUE not null,
    "email" varchar(50) UNIQUE not null,
    "telefone" varchar(15),
    "id_endereco" int not null,
    CONSTRAINT "fornecedores_PK" PRIMARY KEY ("id"),
    CONSTRAINT "fornecedor_endereco_FK" FOREIGN KEY ("id_endereco")
    REFERENCES "endereco"("id")
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

